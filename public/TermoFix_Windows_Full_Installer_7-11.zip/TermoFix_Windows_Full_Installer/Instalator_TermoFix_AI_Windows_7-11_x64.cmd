@echo off
:: ===============================================================
:: TermoFix AI - Pełny Instalator Windows 7/8/10/11 64-bit
:: ===============================================================
if "%PROCESSOR_ARCHITECTURE%"=="x86" (
  if defined PROCESSOR_ARCHITEW6432 (
    "%SystemRoot%\SysNative%\cmd.exe" /c "%~f0" %*
    exit /b
  )
)

title TermoFix AI - Pełny Instalator Windows 7/8/10/11 64-bit
color 0A
cls
echo ===============================================================
echo   TermoFix AI - Pełny Instalator Windows 7/8/10/11 64-bit
echo ===============================================================
echo.
echo Tworzenie skrótu na Pulpicie Windows...
set "DESKTOP=%USERPROFILE%\Desktop"
set "SHORTCUT=%DESKTOP%\TermoFix AI - Serwis Windows.url"
echo [InternetShortcut] > "%SHORTCUT%"
echo URL=https://example.com >> "%SHORTCUT%"
echo IconIndex=0 >> "%SHORTCUT%"
echo IconFile=%SystemRoot%\System32\shell32.dll >> "%SHORTCUT%"
echo.
echo [SUKCES] Utworzono skrót "TermoFix AI - Serwis Windows" na Twoim Pulpicie!
echo.
echo Uruchamianie aplikacji w domyślnej przeglądarce...
start "" "https://example.com" 2>nul || if exist "%ProgramFiles%\Internet Explorer\iexplore.exe" ("%ProgramFiles%\Internet Explorer\iexplore.exe" "https://example.com")
echo.
echo Gotowe! Mozesz zamknac to okno.
pause
