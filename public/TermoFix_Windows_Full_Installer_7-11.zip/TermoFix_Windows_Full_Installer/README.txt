TermoFix AI - Pełny instalator Windows 7/8/10/11 64-bit

Zawartość archiwum:
- Instalator_TermoFix_AI_Windows_7-11_x64.cmd
- Instalator_PowerShell_TermoFix_AI_Windows.ps1

Instrukcje:
1. Rozpakuj archiwum na dowolny komputer z systemem Windows 7, 8, 10 lub 11.
2. Uruchom plik Instalator_TermoFix_AI_Windows_7-11_x64.cmd jako Administrator.
3. Jeżeli PowerShell jest dostępny, możesz również użyć pliku Instalator_PowerShell_TermoFix_AI_Windows.ps1.
4. Po utworzeniu skrótu kliknij go, aby otworzyć TermoFix AI w przeglądarce.

Uwaga:
- Windows 7 może wymagać ręcznej aktualizacji PowerShell i włączenia skryptów.
- Jeśli domyślna przeglądarka nie otworzy aplikacji, spróbuj ręcznie uruchomić skrót.
