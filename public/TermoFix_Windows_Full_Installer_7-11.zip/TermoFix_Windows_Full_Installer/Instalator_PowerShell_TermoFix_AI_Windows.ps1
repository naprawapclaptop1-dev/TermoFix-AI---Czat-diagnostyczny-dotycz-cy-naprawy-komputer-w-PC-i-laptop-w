# TermoFix AI Windows Desktop Installer (PowerShell)
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path -Path $DesktopPath -ChildPath "TermoFix AI Serwis.lnk"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-NoProfile -WindowStyle Hidden -Command "Start-Process 'https://example.com'""
$Shortcut.Description = "TermoFix AI - Serwis PC & Diagnostyka"
$Shortcut.IconLocation = "%SystemRoot%\System32\shell32.dll, 14"
$Shortcut.Save()

Write-Host "[OK] Skrót 'TermoFix AI Serwis' został dodany na Pulpit Windows!" -ForegroundColor Green
Start-Process "https://example.com"
